import { useRef } from 'react';
import { useContext } from 'react/cjs/react.development';
import AuthContext from '../../store/auth-context';
import classes from './ProfileForm.module.css';

const ProfileForm = () => {

  const newEnteredPasswordRef=useRef();
  const authCtx=useContext(AuthContext);

  const submitHandler=()=>{

    const enteredPassword=newEnteredPasswordRef.current.value;

    fetch('https://identitytoolkit.googleapis.com/v1/accounts:update?key=AIzaSyBwW2G3cYPcNEVYO98-H0DmlxPCpXbWUYU',
    {
      method: 'POST',
      body: JSON.stringify({
        idToken: authCtx.token,
        password: enteredPassword,
        returnSecureToken: false
      }),
      headers: {
        'Content-Type':'application/json'
      }
    }).then(res=>{


    });



  };

  return (
    <form className={classes.form} onSubmit={submitHandler}>
      <div className={classes.control}>
        <label htmlFor='new-password'>New Password</label>
        <input type='password' id='new-password' minLength="7" ref={newEnteredPasswordRef}/>
      </div>
      <div className={classes.action}>
        <button>Change Password</button>
      </div>
    </form>
  );
}

export default ProfileForm;
