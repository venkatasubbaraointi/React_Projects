import React from "react";

const NotFound = () => {
  return (
    <div className="centered">
      <p>Page Not Found!</p>
    </div>
  );
};

export default NotFound;
