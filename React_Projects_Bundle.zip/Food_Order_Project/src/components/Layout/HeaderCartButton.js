import React, { useContext, useEffect, useState } from 'react';
import CartIcon from '../Cart/CartIcon';
import CartContext from '../store/cart-context';
import classes from './HeaderCartButton.module.css';

const HeaderCartButton=(props)=>{

    const cartctx=useContext(CartContext);
    const [btnIsHighlighted,setBtnIsHighlighted]=useState(false);
    const {items}=cartctx;

    const numberOfCartItems=cartctx.items.reduce((curnumber,item)=>{return curnumber+item.amount},0);
    const btnclasses=`${classes.button} ${btnIsHighlighted ? classes.bump : ''}`;

    useEffect(()=>{
        if(items.length===0)
        {
            return;
        }
        setBtnIsHighlighted(true);

        const timer = setTimeout(()=>{
            setBtnIsHighlighted(false);
        },300);

        return ()=>{
            clearTimeout(timer);
        }
    },[items]);


    return <button className={btnclasses} onClick={props.onShowCart}>
        <span className={classes.icon}>
            <CartIcon />
        </span>
        <span>
            Your Cart
        </span>
        <span className={classes.badge}>
            {numberOfCartItems}
        </span>
    </button>
};

export default HeaderCartButton;