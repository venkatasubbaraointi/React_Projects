import React, { useContext } from "react";
import { useState } from "react/cjs/react.development";
import CartContext from "../store/cart-context";
import Modal from "../UI/Modal";
import classes from "./Cart.module.css";
import CartItem from "./CartItem";
import CheckOut from "./CheckOut";

const Cart = (props) => {
  const cartctx = useContext(CartContext);
  const [isChecked,SetIsChecked]=useState(false);
  const [isSubmitting ,setIsSubmitting]=useState(false);

  const AddItemHandler = (item) => {
    cartctx.addItem(item);
  };

  const RemoveItemHandler = (id) => {
    cartctx.removeItem(id);
  };

  const orderHandler=()=>{
    SetIsChecked(true);
  };

  const submitOrderHandler=(userdata)=>{
    setIsSubmitting(true);

    fetch('https://react-restapi-2e2fd-default-rtdb.firebaseio.com/meals.json',{
      method: 'POST',
      body: JSON.stringify({
        user: userdata,
        orderedItems: cartctx.items
      })
    });
    setIsSubmitting(false);
  };

  const cartItems = (
    <ul className={classes["cart-items"]}>
      {cartctx.items.map((item) => (
        <CartItem
          key={item.id}
          name={item.name}
          amount={item.amount}
          price={item.price}
          onAdd={AddItemHandler.bind(null,item)}
          onRemove={RemoveItemHandler.bind(null,item.id)}
        />
      ))}
    </ul>
  );

  const cartTotalAmount = `$${cartctx.totalAmount.toFixed(2)}`;
  const hasItems = cartctx.items.length > 0;

  const ModalActions= <div className={classes.actions}>
  <button className={classes["button-alt"]} onClick={props.onClose}>
    Close
  </button>
  {hasItems && <button className={classes.button} onClick={orderHandler}>Order</button>}
</div>;

  return (
    <Modal onClose={props.onClose}>
      {cartItems}
      <div className={classes.total}>
        <span>Total Amount</span>
        <span>{cartTotalAmount}</span>
      </div>

    {isChecked && <CheckOut onConfirm={submitOrderHandler} onCancel={props.onClose}/>}
    {!isChecked && ModalActions}
      
    </Modal>
  );
};

export default Cart;
