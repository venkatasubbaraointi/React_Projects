import React from 'react';
import { useRef, useState } from 'react/cjs/react.development';
import classes from './CheckOut.module.css';

const CheckOut=(props)=>{

    const [formInputIsValidity,setFormInputIsValidity]=useState({
        name: true,
        street: true,
        postal: true,
        city: true
    });

    const isEmpty=(value)=>value.trim()==='';
    const isfivechars=(value)=>value.trim().length!==5;

    const nameInputRef=useRef();
    const streetInputRef=useRef();
    const postalInputRef=useRef();
    const cityInputRef=useRef();

    const confirmHandler=(event)=>{
        event.preventDefault();

        const enteredName=nameInputRef.current.value;
        const enteredStreet=streetInputRef.current.value;
        const enteredPostal=postalInputRef.current.value;
        const enteredCity=cityInputRef.current.value;

        const enteredNameisValid= !isEmpty(enteredName);
        const enteredStreetisValid=!isEmpty(enteredStreet);
        const enteredPostalisValid=!isEmpty(enteredPostal);
        const enteredCityisValid=isfivechars(enteredCity);

        setFormInputIsValidity({
            name: enteredNameisValid,
            street: enteredStreetisValid,
            postal: enteredPostalisValid,
            city: enteredCityisValid
        });

        const formisValid= enteredNameisValid && enteredStreetisValid && enteredPostalisValid && enteredCityisValid;

        if(!formisValid){
            return;
        }

        props.onConfirm({
            name: enteredName,
            street: enteredStreet,
            postal: enteredPostal,
            city: enteredCity
        });
    };

    const nameInputClasses=`${classes.control} ${formInputIsValidity.name ? '':classes.invalid }`;
    const streetInputClasses=`${classes.control} ${formInputIsValidity.street ? '':classes.invalid }`;
    const postalInputClasses=`${classes.control} ${formInputIsValidity.postal ? '':classes.invalid }`;
    const cityInputClasses=`${classes.control} ${formInputIsValidity.city ? '':classes.invalid }`;

    return (
        <form className={classes.form} onSubmit={confirmHandler}>
            <div className={nameInputClasses}>
                <label htmlFor='name'>Your Name</label>
                <input type="text" id="name" ref={nameInputRef}/>
                {!formInputIsValidity.name && <p>Please enter a valid name</p>}
            </div>

            <div className={streetInputClasses}>
                <label htmlFor='street'>Street</label>
                <input type="text" id="street" ref={streetInputRef}/>
                {!formInputIsValidity.street && <p>Please enter a valid Street</p>}
            </div>

            <div className={postalInputClasses}>
                <label htmlFor='postal'>Postal Code</label>
                <input type="text" id="postal" ref={postalInputRef}/>
                {!formInputIsValidity.postal && <p>Please enter a valid Postal Code</p>}
            </div>

            <div className={cityInputClasses}>
                <label htmlFor='city'>City</label>
                <input type="text" id="city" ref={cityInputRef}/>
                {!formInputIsValidity.city && <p>Please enter a valid City</p>}
            </div>

            <div className={classes.actions}>
                <button type="button" onClick={props.onCancel}>Cancel</button>
                <button className={classes.onSubmit}>Confirm</button>
            </div>
        </form>
    );
};

export default CheckOut;