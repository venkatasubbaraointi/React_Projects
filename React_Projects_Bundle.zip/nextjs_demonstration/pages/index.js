
function HomePage(){
    return (
        <h1>Welcome to Home Page</h1>
    );
}

export default HomePage;