import Link from 'next/link';
import React from 'react';
function NewsPage(){
    return (
        <React.Fragment>
        <h1>The News Page</h1>
        <ul>
            <li>
                <Link href='/news/learning-next' >We are Learning Next.Js</Link>
            </li>
            <li>
                Next.js is a React Full Stack Framework
            </li>
        </ul>
        </React.Fragment>
    );
}

export default NewsPage;