const Welcome=()=>{
    return <h1>
        Welcome to React Router
    </h1>;
};

export default Welcome;