function Wrapper(props){
    return props.children;
}

export default Wrapper