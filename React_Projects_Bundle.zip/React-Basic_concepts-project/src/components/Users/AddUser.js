import React, { useState, useRef } from 'react';
import styles from './AddUser.module.css';
import Card from '../UI/Card.js';
import Button from '../UI/Button.js';
import ErrorModal from '../UI/ErrorModal';

function AddUser(props){

    const [enteredUsername,SetEnteredUsername]=useState('');
    const [enteredAge,SetEnteredAge]=useState('');
    const [error,setError]=useState();

    const inputNameRef=useRef();
    const ageInputRef=useRef();

    const usernameHandler=(event)=>{
        SetEnteredUsername(event.target.value);
    };

    const ageHandler=(event)=>{
        SetEnteredAge(event.target.value);
    };

    const errorConfirmHandler=()=>{
        setError(null);
    };

    const AddUserHandler=(event)=>{
        event.preventDefault();
        if(enteredUsername.trim().length===0 || enteredAge.trim().length===0)
        {
            setError(
                {
                    title: 'Invalid Input',
                    message: 'Please enter valid username and age(Not empty)'
                }
            );
            return;
        }
        if(+enteredAge<1)
        {
            setError(
                {
                    title: 'Invalid Age Input',
                    message: 'Age must be greater than 1(>1)'
                }
            );
            return;
        }

        props.onAddUserList(enteredAge,enteredUsername);

        SetEnteredUsername('');
        SetEnteredAge('');
    };

    return (
        <React.Fragment>
        {error && <ErrorModal title={error.title} message={error.message} onConfirm={errorConfirmHandler}></ErrorModal>}
        <Card className={styles.input}>
        <form onSubmit={AddUserHandler}>
            <label htmlFor='username'>UserName</label>
            <input type="text" id='username' value={enteredUsername} onChange={usernameHandler} ref={inputNameRef}></input>
            <label htmlFor='age'>Age(in years)</label>
            <input type="number" id='age' value={enteredAge} onChange={ageHandler} ref={ageInputRef}></input>

            <Button type="submit">Add User</Button>
        </form>
        </Card>
        </React.Fragment>
    );
}

export default AddUser;