import React, {useState} from 'react';
import AddUser from './components/Users/AddUser';
import UserList from './components/Users/UserList';


function App() {

  const [userlist,setUserList]=useState([]); 

  const UserListHandler=(uName,uAge)=>{
    setUserList((prevList)=>{
      return [...prevList,{name: uName,age: uAge, id:Math.random()}];
    });
  };

  return (
    <div>
      <AddUser onAddUserList={UserListHandler}/>
      <UserList users={userlist}/>
    </div>
  );
}

export default App;
