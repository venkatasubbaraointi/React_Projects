import { useEffect, useState} from 'react';

const SimpleInput = (props) => {

  const [enteredName,SetEnteredName]=useState('');
  const [enteredNameTouched,setEnteredNameTouched]=useState(false);
  const enteredNameIsValid= enteredName.trim()!=='';
  const [formIsValid,SetFormIsValid]=useState(false);

  const nameEnteredInputIsValid=!enteredNameIsValid && enteredNameTouched;
  const nameInputClasses=nameEnteredInputIsValid? 'form-control invalid' : 'form-control';
  
  const [enteredEmail,setEmailName]=useState('');
  const [enteredEmailTouched,setEnteredEmailTouched]=useState(false);

  const emailEnteredInputIsInValid= !(enteredEmail.trim().includes('@')) && enteredEmailTouched;
  const emailInputClasses=emailEnteredInputIsInValid ? 'form-control invalid': 'form-control';

  useEffect(()=>{
    if(enteredNameIsValid && !emailEnteredInputIsInValid){
      SetFormIsValid(true);
    }
    else{
      SetFormIsValid(false);
    }
  },[nameEnteredInputIsValid,emailEnteredInputIsInValid])

  const nameEnteredBlurHandler=()=>{
    setEnteredNameTouched(true);
  }

  const nameEnteredHandler=(event)=>{
    SetEnteredName(event.target.value);
  }


  const emailhandler=(event)=>{
    setEmailName(event.target.value);
  }

  const emailblurHandler=(event)=>{
    setEnteredEmailTouched(true);
  }


  const formSubmissionHandler=(event)=>{
    event.preventDefault();

    if(!enteredNameIsValid && !enteredEmail.trim().includes('@')){
      return;
    }

    setEnteredNameTouched(false);
    SetEnteredName('');

    setEnteredEmailTouched(false);
    setEmailName('');
  }


  
  return (
    <form onSubmit={formSubmissionHandler}>
      <div className={nameInputClasses}>
        <label htmlFor='name'>Your Name</label>
        <input type='text' id='name' onChange={nameEnteredHandler} onBlur={nameEnteredBlurHandler} value={enteredName}/>
      </div>
      {nameEnteredInputIsValid && <p className='error-text'>Name must not be empty</p>}

      
      <div className={emailInputClasses}>
        <label htmlFor='email'>E-Mail</label>
        <input type='email' id='email' onChange={emailhandler} onBlur={emailblurHandler} value={enteredEmail}/>
      </div>
      {emailEnteredInputIsInValid && <p className='error-text'>Please Enter Valid email</p>}

      <div className="form-actions">
        <button disabled={!formIsValid}>Submit</button>
      </div>
    </form>
  );
};

export default SimpleInput;
