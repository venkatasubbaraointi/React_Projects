import { useEffect, useState } from "react/cjs/react.development";
import MeetupList from "../components/meetups/MeetupList";

const DUMMY_MEETUPS = [
  {
    id: "m1",
    title: "A First MeetUp",
    image:
      "https://media-exp1.licdn.com/dms/image/C5603AQHD9t6NaTzeEQ/profile-displayphoto-shrink_200_200/0/1619850425703?e=1648684800&v=beta&t=mFZCibJI10SQOSFr_Vpk_OEAWLb3HlPaueUNKWSI1Sg",
    address: "525 East Armour, Kansas City, MO",
    description: "This is the First MeetUp",
  },
  {
    id: "m2",
    title: "A Second MeetUp",
    image:
      "https://media-exp1.licdn.com/dms/image/C5603AQHD9t6NaTzeEQ/profile-displayphoto-shrink_200_200/0/1619850425703?e=1648684800&v=beta&t=mFZCibJI10SQOSFr_Vpk_OEAWLb3HlPaueUNKWSI1Sg",
    address: "3425 West Armour, Kansas City, MO",
    description: "This is the second MeetUp",
  },
];

function HomePage(props) {
  return <MeetupList meetups={props.meetups} />;
}

export async function getStaticPaths() {
  
    return {
    fallback: false,
    paths: [
      {
        params: {
          meetupId: "m1",
        },
      },
      {
        params: {
          meetupId: "m2",
        },
      },
    ],
  };
}

export async function getStaticProps(context) {
  //fetch the data from an api

  const meetupId = context.params.meetupId;

  return {
    props: {
      meetupData: {
        id: meetupId,
        title: "A First MeetUp",
        image:
          "https://media-exp1.licdn.com/dms/image/C5603AQHD9t6NaTzeEQ/profile-displayphoto-shrink_200_200/0/1619850425703?e=1648684800&v=beta&t=mFZCibJI10SQOSFr_Vpk_OEAWLb3HlPaueUNKWSI1Sg",
        address: "525 East Armour, Kansas City, MO",
        description: "This is the First MeetUp",
      },
    },
    revalidate: 10,
  };
}

// export async function getServerSideProps(context){
//     const req=context.req;
//     const res=context.res;

//     return {
//         props:{
//             meetups: DUMMY_MEETUPS
//         }
//     }
// }

export default HomePage;
