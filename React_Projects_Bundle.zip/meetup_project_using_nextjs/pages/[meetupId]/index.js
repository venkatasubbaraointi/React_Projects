import { Fragment } from "react/cjs/react.production.min";
import MeetupDetail from "../../components/meetups/MeetupDetail";

function MeetupDetails() {
  return (
    <MeetupDetail
      image="https://media-exp1.licdn.com/dms/image/C5603AQHD9t6NaTzeEQ/profile-displayphoto-shrink_200_200/0/1619850425703?e=1648684800&v=beta&t=mFZCibJI10SQOSFr_Vpk_OEAWLb3HlPaueUNKWSI1Sg"
      title="First Meetup"
      address='Some Street in the World'
      description='This is the First Meetup'
    />
  );
}

export default MeetupDetails;
